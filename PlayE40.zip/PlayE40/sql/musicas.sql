create table Musicas (
    id integer primary key autoincrement,
    nome varchar(50) not null,
    artista text not null,
    genero varchar(1),
    ano integer not null,
    duracao integer not null,
    
    
)