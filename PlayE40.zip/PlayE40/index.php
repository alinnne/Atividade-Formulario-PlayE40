<?php
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);
error_reporting(E_ALL);

require_once ('util/conexao.php');
$con = conexao::getconexao();

?>




<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PlayE40</title>
</head>
<body>
    <h1>Bem vindo ao PlayE40!</h1>
    <h1>Aqui você cadastra as músicas que você deseja escutar na nossa rádio essa semana!</h1>
    
    
    <div>
        <p>você pode cadastrar até 10 músicas por dia.</p>
        <p>As músicas serão tocadas de acordo com a ordem de cadastro .</p>
        <p>As músicas cadastradas hoje serão tocadas amanhã.</p>
        <p>As músicas serão tocadas no nosso programa "Tu Eliges" durante a tarde e durante a manhã na 91.1FM</p>
        <p>O "Tu Eliges" da manhã vai das 8:30AM às 10:30AM  e a tarde das 17:30PM às 20:00PM (Horário de Brasília)</p>
    </div>
    

    <button>Cadastre sua música aqui!</button>
    
    
    
</body>
</html>